#!/bin/bash
date
current_time=$(date +%s)
echo "--TIME--"
echo "$current_time"
echo "--TIME2--"
echo "$((current_time * 2))"

#For Loop
for i in {1..20};
do 
	echo "$i"
done




